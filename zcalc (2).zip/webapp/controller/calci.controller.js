sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("zcalc.ZCALC.zcalc.controller.calci", {
		onInit: function () {},

		onPress: function (okey) {

			var oVal1 = this.getView().byId("inpval1").getValue();
			var oVal2 = this.getView().byId("inpval2").getValue();
			var oResult = this.getView().byId("inp3");
			switch (okey) {
			case "add":
				oResult.setValue(parseInt(oVal1, 10) + parseInt(oVal2, 10));
				break;
			case "sub":
				oResult.setValue(parseInt(oVal1, 10) - parseInt(oVal2, 10));
				break;
			case "mul":
				oResult.setValue(parseInt(oVal1, 10) * parseInt(oVal2, 10));
				break;
			case "div":
				oResult.setValue(parseInt(oVal1, 10) / parseInt(oVal2, 10));
				break;
			}
			

		},
		
		onClear:function(){
			this.getView().byId("inpval1").setValue();
			this.getView().byId("inpval2").setValue();
			this.getView().byId("inp3").setValue();
		}

	});
});