sap.ui.define([
	"zcalc/ZCALC/zcalc/test/unit/controller/calci.controller"
], function () {
	"use strict";
});