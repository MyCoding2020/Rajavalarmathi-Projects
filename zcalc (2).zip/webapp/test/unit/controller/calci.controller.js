/*global QUnit*/

sap.ui.define([
	"zcalc/ZCALC/zcalc/controller/calci.controller"
], function (Controller) {
	"use strict";

	QUnit.module("calci Controller");

	QUnit.test("I should test the calci controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});